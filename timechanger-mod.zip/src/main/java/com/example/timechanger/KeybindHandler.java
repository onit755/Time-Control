package com.example.timechanger;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;

public class KeybindHandler {
    private static final KeyBinding TOGGLE_MOD = KeyBindingHelper.registerKeyBinding(
        new KeyBinding("key.timechanger.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.misc"));
    private static final KeyBinding OPEN_SETTINGS = KeyBindingHelper.registerKeyBinding(
        new KeyBinding("key.timechanger.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "key.categories.misc"));

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (TOGGLE_MOD.wasPressed()) {
                TimeChangerClient.modEnabled = !TimeChangerClient.modEnabled;
            }
            while (OPEN_SETTINGS.wasPressed()) {
                // placeholder for config screen
            }
        });
    }
}