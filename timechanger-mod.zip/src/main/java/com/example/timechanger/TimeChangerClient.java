package com.example.timechanger;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class TimeChangerClient implements ClientModInitializer {
    public static boolean modEnabled = true;
    public static int customTime = 1000;
    public static boolean overrideTime = true;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world != null && modEnabled && overrideTime) {
                client.world.setTimeOfDay(customTime);
            }
        });

        KeybindHandler.init();
    }
}